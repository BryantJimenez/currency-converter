<div class="footer-wrapper">
    <div class="footer-section f-section-1">
    </div>
    <div class="footer-section f-section-2">
        <p class="text-right"><span class="text-primary">{{ env('APP_NAME') }}</span> Todos los derechos reservados {{ date("Y") }} - Desarrollado a medida por <a href="https://www.otterscompany.com" target="_blank" class="text-primary">Otters Company</a>.</p>
    </div>
</div>